// OSoundInput.cpp: implementation of the COSoundInput class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OSoundInput.h"
#include "MMREG.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
UINT WaveInThread(LPVOID pParam)
{
   UINT result;
   UINT FirstPass = TRUE;

	if (FirstPass)
	result = WaitForSingleObject(((COSoundInput*)pParam)->m_WaveInEvent,INFINITE);
	FirstPass = FALSE;
    while (!((COSoundInput*)pParam)->m_TerminateThread)
	{
		result = WaitForSingleObject(((COSoundInput*)pParam)->m_WaveInEvent,INFINITE);
		if ((result == WAIT_OBJECT_0)&&(!((COSoundInput*)pParam)->m_TerminateThread ))
		{
			((COSoundInput*)pParam)->AddBuffer();
		    
		}
		else
			return 0; 
	}
return 0;
}


COSoundInput::COSoundInput()
{
  m_Toggle=0;
  check=FALSE;
  InputBuffer=new SHORT[6000];
  m_NbMaxSamples =2048;
  m_CalOffset = DEFAULT_CAL_OFFSET;
  m_CalGain = DEFAULT_CAL_GAIN;
  m_WaveInSampleRate = 11025;
  PORT=56740;
  isReq=TRUE;

}

COSoundInput::~COSoundInput()
{
	
	CloseMic();
}




void COSoundInput::OpenMic()
{
   
	MMRESULT result;
    result=waveInGetNumDevs(); 
	if (result == 0)
	{
        AfxMessageBox("No Sound Device");
	
	}


   result=waveInGetDevCaps (0, &m_WaveInDevCaps, sizeof(WAVEINCAPS));
   
   if ( result!= MMSYSERR_NOERROR)
   {
       AfxMessageBox(_T("Cannot determine sound card capabilities !"));
   }


	m_WaveInEvent = CreateEvent(NULL,FALSE,FALSE,"WaveInThreadEvent");
	m_TerminateThread = FALSE;
	m_WaveInThread= AfxBeginThread(WaveInThread,this,THREAD_PRIORITY_NORMAL,0,CREATE_SUSPENDED,NULL);   
	m_WaveInThread->m_bAutoDelete = TRUE;
	m_WaveInThread->ResumeThread();
	WaveInitFormat(1,m_WaveInSampleRate ,16); 
	result = waveInOpen( &m_WaveIn,WAVE_MAPPER, &m_WaveFormat,(DWORD)m_WaveInEvent ,NULL ,CALLBACK_EVENT); 
	if ( result!= MMSYSERR_NOERROR)
	{
        AfxMessageBox(_T("Cannot Open Sound Input Device!"));
	 	m_WaveInThread->SuspendThread();
        return;
	}
  	m_SizeRecord = m_NbMaxSamples;

    m_Toggle=0;
    m_WaveHeader.lpData = (CHAR *)InputBuffer;
    m_WaveHeader.dwBufferLength = m_SizeRecord*2;
	m_WaveHeader.dwFlags = 0;
    result = waveInPrepareHeader( m_WaveIn, &m_WaveHeader, sizeof(WAVEHDR) ); 
   if ( (result!= MMSYSERR_NOERROR) || ( m_WaveHeader.dwFlags != WHDR_PREPARED) )
   {
        AfxMessageBox(_T("Cannot Prepare Header !"));
		return ;

   }

   result = waveInAddBuffer( m_WaveIn, &m_WaveHeader, sizeof(WAVEHDR) );
   if  (result!= MMSYSERR_NOERROR) 
   {
        AfxMessageBox(_T("Cannot Add Buffer !"));
        return ;
   }

   
   result = waveInStart( m_WaveIn );
   if  (result!= MMSYSERR_NOERROR) 
   {
        AfxMessageBox(_T("Cannot Start Wave In !"));
        return ;   
   }
  



}
void COSoundInput::AddBuffer()
{
 MMRESULT result;

	result = waveInUnprepareHeader( m_WaveIn, &m_WaveHeader, sizeof(WAVEHDR) ); 
   if  (result!= MMSYSERR_NOERROR) 
   {
        AfxMessageBox(_T("Cannot UnPrepareHeader !"));
        return;
   };
 	m_SizeRecord = m_NbMaxSamples;
    m_WaveHeader.lpData = (CHAR *)InputBuffer;
    m_WaveHeader.dwBufferLength = m_SizeRecord *2;
	m_WaveHeader.dwFlags = 0;
    result = waveInPrepareHeader( m_WaveIn, &m_WaveHeader, sizeof(WAVEHDR) ); 
   if ( (result!= MMSYSERR_NOERROR) || ( m_WaveHeader.dwFlags != WHDR_PREPARED) )
   {
	   AfxMessageBox(_T("Cannot Prepare Header !"));
       return ;  
   }

   result = waveInAddBuffer(m_WaveIn, &m_WaveHeader, sizeof(WAVEHDR) );
   if  (result!= MMSYSERR_NOERROR) 
   {
	   AfxMessageBox(_T("Cannot Add Buffer !"));
	   return;
   }


   result = waveInStart( m_WaveIn );
   if  (result!= MMSYSERR_NOERROR) 
   {
	   AfxMessageBox(_T("Cannot Start Wave In !"));
       return ;
   }
   
   if(check)
   VOICE->Send(InputBuffer,6000);
   


}
void COSoundInput::StartSendingVoice(CString ip)
{

if(!check)
{
 VOICE=new COVoiceClient;
 DWORD arg=0;
 VOICE->IOCtl(FIONBIO,&arg); 
 VOICE->m_isRec=FALSE; 
 if(VOICE->Create())
 {
  if(VOICE->Connect(ip,PORT+100))
    check=TRUE;
  
 }

OpenMic();
}
}

void COSoundInput::WaveInitFormat(WORD nCh,DWORD nSampleRate,WORD BitsPerSample)
{
		m_WaveFormat.wFormatTag = WAVE_FORMAT_PCM;
		m_WaveFormat.nChannels = 2;//nCh;
		m_WaveFormat.nSamplesPerSec = 22050;//nSampleRate;
		m_WaveFormat.nAvgBytesPerSec =22050*2*16/8; //nSampleRate * nCh * BitsPerSample/8;//64000;
		m_WaveFormat.nBlockAlign = 2*16/8;//m_WaveFormat.nChannels * BitsPerSample/8;
		m_WaveFormat.wBitsPerSample = 16;//BitsPerSample;
		m_WaveFormat.cbSize = 0;
}   

void COSoundInput::StopMic()
{
	waveInStop(m_WaveIn);
	waveInReset(m_WaveIn);
}

void COSoundInput::CloseMic()
{
	m_TerminateThread = TRUE;
    if (m_WaveInEvent )
		SetEvent(m_WaveInEvent);
    Sleep(50);  
	if (m_WaveIn) 
		waveInStop(m_WaveIn);
    if (m_WaveIn) 
		waveInClose(m_WaveIn);

}


void COSoundInput::EndVoice()
{

VOICE->Close();
CloseMic();
VOICE->EndVoice();

}
