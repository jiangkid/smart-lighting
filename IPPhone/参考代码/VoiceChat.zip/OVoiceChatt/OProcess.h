// OProcess.h: interface for the COProcess class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OPROCESS_H__590925A4_D71F_48DF_9A58_9470CB4C33BC__INCLUDED_)
#define AFX_OPROCESS_H__590925A4_D71F_48DF_9A58_9470CB4C33BC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "OSoundInput.h"
class COProcess  
{
public:

	void OnVoiceSocketClose(int err,LPVOID param);
	void EndVoice();
	COSoundInput  *Sound;
	void OnClose(int err,LPVOID param);
	void VoiceInvStatus(bool status,LPCTSTR recip);
	void OnReceive(int err,LPVOID param);
	void SendVoiceInvit(CString nick,CString ip);
	void OnAcceptServer(int err,LPVOID param);
	CString m_MyNick;
	UINT PORT;
	void SetParent(LPVOID param);
	COProcess();
	COProcess(CString nick);
	virtual ~COProcess();

};

#endif // !defined(AFX_OPROCESS_H__590925A4_D71F_48DF_9A58_9470CB4C33BC__INCLUDED_)
