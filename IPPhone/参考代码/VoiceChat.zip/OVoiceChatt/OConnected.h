#if !defined(AFX_OCONNECTED_H__701A485A_6B21_4462_93D6_C1B0E79F4BA1__INCLUDED_)
#define AFX_OCONNECTED_H__701A485A_6B21_4462_93D6_C1B0E79F4BA1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OConnected.h : header file
//
#include "OProcess.h"


/////////////////////////////////////////////////////////////////////////////
// COConnected command target

class COConnected : public CSocket
{
// Attributes
public:

// Operations
public:
	COProcess *m_ptrProcess;
	COConnected();
	virtual ~COConnected();

// Overrides
public:
	CString ip;
	void SetProcess(COProcess *ptrProcess);
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COConnected)
	public:
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(COConnected)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OCONNECTED_H__701A485A_6B21_4462_93D6_C1B0E79F4BA1__INCLUDED_)
