#if !defined(AFX_OVOICESERVER_H__CF87F1F7_F915_4A13_A62E_A95867BEF03A__INCLUDED_)
#define AFX_OVOICESERVER_H__CF87F1F7_F915_4A13_A62E_A95867BEF03A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OVoiceServer.h : header file
//

#include "OVoiceClient.h"

/////////////////////////////////////////////////////////////////////////////
// COVoiceServer command target

class COVoiceServer : public CSocket
{
// Attributes
public:
	COVoiceClient *m_ClientSock;

// Operations
public:
	COVoiceServer();
	virtual ~COVoiceServer();

// Overrides
public:
	void CloseSockect();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COVoiceServer)
	public:
	virtual void OnAccept(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(COVoiceServer)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OVOICESERVER_H__CF87F1F7_F915_4A13_A62E_A95867BEF03A__INCLUDED_)
