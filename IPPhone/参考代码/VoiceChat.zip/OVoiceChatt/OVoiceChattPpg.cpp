// OVoiceChattPpg.cpp : Implementation of the COVoiceChattPropPage property page class.

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OVoiceChattPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(COVoiceChattPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(COVoiceChattPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(COVoiceChattPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(COVoiceChattPropPage, "OVOICECHATT.OVoiceChattPropPage.1",
	0x4800771e, 0x721b, 0x4053, 0xb2, 0xef, 0x23, 0x71, 0x8b, 0xc9, 0xd3, 0xe4)


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattPropPage::COVoiceChattPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for COVoiceChattPropPage

BOOL COVoiceChattPropPage::COVoiceChattPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_OVOICECHATT_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattPropPage::COVoiceChattPropPage - Constructor

COVoiceChattPropPage::COVoiceChattPropPage() :
	COlePropertyPage(IDD, IDS_OVOICECHATT_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(COVoiceChattPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattPropPage::DoDataExchange - Moves data between page and properties

void COVoiceChattPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(COVoiceChattPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattPropPage message handlers
