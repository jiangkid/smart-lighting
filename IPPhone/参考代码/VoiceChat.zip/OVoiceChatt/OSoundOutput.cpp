// OSoundOutput.cpp: implementation of the COSoundOutput class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OSoundOutput.h"
#include "MMREG.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

UINT WaveOutThreadProc(LPVOID pParam);
void CALLBACK WaveOutProc(HWAVEOUT hwo,UINT uMsg,DWORD dwInstance,DWORD dwParam1,DWORD dwParam2);


COSoundOutput::COSoundOutput()
{

  m_NbMaxSamples = MAX_OUTPUT_SAMPLES;
  m_WaveOutSampleRate = 11025;
  m_Toggle = 0;



}

COSoundOutput::~COSoundOutput()
{
CloseOutput();
}



void COSoundOutput::OpenOutput()
{
    MMRESULT result;
    result=waveOutGetNumDevs(); 
	if (result == 0)
	{
     AfxMessageBox("No Sound Output Device");
		
	};
    result=waveOutGetDevCaps (0, &m_WaveOutDevCaps, sizeof(WAVEOUTCAPS));
    if ( result!= MMSYSERR_NOERROR)
    {
       AfxMessageBox(_T("Cannot determine card capabilities !"));
	   return ; 
    }
	m_Terminate = FALSE;
#ifndef CALL_BACK_TEST
    m_WaveOutEvent = CreateEvent(NULL,FALSE,FALSE,"WaveOutThreadEvent");
	m_WaveOutThread= AfxBeginThread(WaveOutThreadProc,this,THREAD_PRIORITY_TIME_CRITICAL,0,CREATE_SUSPENDED,NULL);   
	m_WaveOutThread->m_bAutoDelete = TRUE;
#endif
WaveInitFormat(1,m_WaveOutSampleRate,16); 
#ifdef CALL_BACK_TEST
	result = waveOutOpen( &m_WaveOut,WAVE_MAPPER, &m_WaveFormat,(DWORD)WaveOutProc ,(ULONG)this ,CALLBACK_FUNCTION); 
#else
	result = waveOutOpen( &m_WaveOut,WAVE_MAPPER, &m_WaveFormat,(DWORD)m_WaveOutEvent ,NULL ,CALLBACK_EVENT); 
#endif

	if ( result!= MMSYSERR_NOERROR)
	{
        AfxMessageBox(_T("Cannot Open OutPut Device!"));
	    return ;
	}

	m_Toggle = 0;
	m_SizeRecord = m_NbMaxSamples;
    m_WaveHeader[m_Toggle].lpData = (CHAR *)OutputBuffer;
    m_WaveHeader[m_Toggle].dwBufferLength = m_SizeRecord*2;
	m_WaveHeader[m_Toggle].dwFlags = 0;
	//m_WaveHeader[m_Toggle].dwLoops = 1;

    result = waveOutPrepareHeader( m_WaveOut, &m_WaveHeader[m_Toggle], sizeof(WAVEHDR) ); 
 
   if ( (result!= MMSYSERR_NOERROR) || ( m_WaveHeader[m_Toggle].dwFlags != WHDR_PREPARED) )
   {
        AfxMessageBox(_T("Cannot Prepare Header !"));
	    return ;
   }

   result = waveOutWrite( m_WaveOut, &m_WaveHeader[m_Toggle], sizeof(WAVEHDR) );
   if  (result!= MMSYSERR_NOERROR) 
   {
        AfxMessageBox(_T("Cannot Write Buffer !"));
	    return ;
   }

    m_Toggle = 1;
	m_SizeRecord= m_NbMaxSamples;
    m_WaveHeader[m_Toggle].lpData = (CHAR *)OutputBuffer;
    m_WaveHeader[m_Toggle].dwBufferLength = m_SizeRecord*2;
	m_WaveHeader[m_Toggle].dwFlags = 0;
    //m_WaveHeader[m_Toggle].dwLoops = 1;
	result = waveOutPrepareHeader( m_WaveOut, &m_WaveHeader[m_Toggle], sizeof(WAVEHDR) ); 
  
   if ( (result!= MMSYSERR_NOERROR) || ( m_WaveHeader[m_Toggle].dwFlags != WHDR_PREPARED) )
   {
        AfxMessageBox(_T("Cannot Prepare Header !"));
	    return ;
   }

   result = waveOutWrite( m_WaveOut, &m_WaveHeader[m_Toggle], sizeof(WAVEHDR) );
   if  (result!= MMSYSERR_NOERROR) 
   {
        AfxMessageBox(_T("Cannot Write Buffer !"));
		return ;
	    
   }

#ifndef CALL_BACK_TEST
	m_WaveOutThread->ResumeThread();
#endif

   
}


void COSoundOutput::AddBuffer()
{


    
	if (m_Toggle == 0) 
	   m_Toggle = 1; 
   else 
   m_Toggle = 0;
 
	 MMRESULT result;
   
   result = waveOutUnprepareHeader( m_WaveOut, &m_WaveHeader[m_Toggle], sizeof(WAVEHDR) ); 
   if  (result!= MMSYSERR_NOERROR) 
   {
        AfxMessageBox(_T("Cannot UnPrepareHeader !"));
        return;
   }
 	m_SizeRecord = m_NbMaxSamples;
    m_WaveHeader[m_Toggle].lpData = (CHAR *)OutputBuffer;
	m_WaveHeader[m_Toggle].dwBufferLength = m_SizeRecord *2;
	m_WaveHeader[m_Toggle].dwLoops = 1;
	m_WaveHeader[m_Toggle].dwFlags = 0; 


	
    result = waveOutPrepareHeader( m_WaveOut, &m_WaveHeader[m_Toggle], sizeof(WAVEHDR) ); 
   if ( (result!= MMSYSERR_NOERROR) || ( m_WaveHeader[m_Toggle].dwFlags != WHDR_PREPARED) )
   {
	   AfxMessageBox(_T("Cannot Prepare Header !"));
       return;
   }

   result = waveOutWrite( m_WaveOut, &m_WaveHeader[m_Toggle], sizeof(WAVEHDR) );
   if  (result!= MMSYSERR_NOERROR) 
   {
	   AfxMessageBox(_T("Cannot Add Buffer !"));
	   return ;
   }


   
 
   
   
   

}



void COSoundOutput:: WaveInitFormat(WORD nCh,DWORD nSampleRate,WORD BitsPerSample)
{
		m_WaveFormat.wFormatTag = WAVE_FORMAT_PCM;
		m_WaveFormat.nChannels = 2;//nCh;
		m_WaveFormat.nSamplesPerSec = 22050;///nSampleRate;
		m_WaveFormat.nAvgBytesPerSec =22050*2*16/8; //nSampleRate * nCh * BitsPerSample/8;//64000
		m_WaveFormat.nBlockAlign =2*16/8; //m_WaveFormat.nChannels * BitsPerSample/8;
		m_WaveFormat.wBitsPerSample =16; //BitsPerSample;
		m_WaveFormat.cbSize = 0;
}   



void COSoundOutput::CloseOutput()
{
	if (m_WaveOut) 
		waveOutPause(m_WaveOut);
    Sleep(50);
	
	m_Terminate = TRUE;
    if (m_WaveOutEvent )
		SetEvent(m_WaveOutEvent);
    Sleep(50);  

   if (m_WaveOut) 
   {
		waveOutReset(m_WaveOut);
		waveOutClose(m_WaveOut);
   }
}

void COSoundOutput::StopOutput()
{
	waveOutPause(m_WaveOut);
}



#define PT_S ((COSoundOutput*)pParam) 

UINT WaveOutThreadProc(void * pParam)
{

   UINT result;
   UINT FirstPass = TRUE;


	if ( FirstPass)
		result = WaitForSingleObject(PT_S->m_WaveOutEvent,INFINITE);
	FirstPass = FALSE;
    
	while (!PT_S->m_Terminate)
	{
		result = WaitForSingleObject(PT_S->m_WaveOutEvent,INFINITE);
		if ((result == WAIT_OBJECT_0)&&(!PT_S->m_Terminate ))
		{
			PT_S->AddBuffer();  
		   
		}
		else
			return 0; 
	}
    return 0;
}


#ifdef CALL_BACK_TEST

void CALLBACK WaveOutProc(HWAVEOUT hwo,UINT uMsg,DWORD pParam,DWORD dwParam1,DWORD dwParam2)
{
	if (!PT_S->m_Terminate )
	switch (uMsg)
	{
	case WOM_DONE:
		PT_S->AddBuffer();
	    
		break;
	case WOM_OPEN:
		break;
	case WOM_CLOSE:
		break;
	}
}

#endif

