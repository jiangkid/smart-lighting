// OVoiceServer.cpp : implementation file
//

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OVoiceServer.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COVoiceServer

COVoiceServer::COVoiceServer()
{
}

COVoiceServer::~COVoiceServer()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(COVoiceServer, CSocket)
	//{{AFX_MSG_MAP(COVoiceServer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// COVoiceServer member functions

void COVoiceServer::OnAccept(int nErrorCode) 
{
   
	m_ClientSock=new COVoiceClient;
    Accept(*m_ClientSock);
	CSocket::OnAccept(nErrorCode);
}

void COVoiceServer::CloseSockect()
{




}
