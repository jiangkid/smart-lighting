// OSoundInput.h: interface for the COSoundInput class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OSOUNDINPUT_H__8C082606_E0BE_49CC_B643_964529B450FB__INCLUDED_)
#define AFX_OSOUNDINPUT_H__8C082606_E0BE_49CC_B643_964529B450FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif
#include <mmsystem.h>

//#define MAX_SAMPLES 8192  
//#define MAX_VOIE 2
//#define MAX_SIZE_SAMPLES  1 
//#define MAX_SIZE_INPUT_BUFFER   MAX_SAMPLES*MAX_VOIE*MAX_SIZE_SAMPLES 
#define DEFAULT_CAL_OFFSET -395
#define DEFAULT_CAL_GAIN   1.0
#include "OVoiceClient.h"
class COSoundInput  
{
public:

	BOOL isReq;
	void EndVoice();
	UINT PORT;
	COSoundInput();
	virtual ~COSoundInput();
	void StopMic();
	void CloseMic();
	void AddBuffer();
    void StartSendingVoice(CString ip);
    void OpenMic();
	void WaveInitFormat(WORD nCh,DWORD nSampleRate,WORD BitsPerSample);
	//data members

    SHORT  *InputBuffer;
	WAVEINCAPS		m_WaveInDevCaps;
    HWAVEIN			m_WaveIn;
	WAVEHDR			m_WaveHeader;
    WAVEFORMATEX	m_WaveFormat;
	short m_CalOffset;
	double m_CalGain;
	HANDLE m_WaveInEvent;
	CWinThread * m_WaveInThread;
	BOOL m_TerminateThread,check;
	UINT m_WaveInSampleRate,m_SizeRecord;
	int m_NbMaxSamples;
	WORD 	m_Toggle;
	COVoiceClient *VOICE;
	
	

};

#endif // !defined(AFX_OSOUNDINPUT_H__8C082606_E0BE_49CC_B643_964529B450FB__INCLUDED_)
