// OConnected.cpp : implementation file
//

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OConnected.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COConnected

COConnected::COConnected()
{
}

COConnected::~COConnected()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(COConnected, CSocket)
	//{{AFX_MSG_MAP(COConnected)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// COConnected member functions

void COConnected::OnReceive(int nErrorCode) 
{
	
	m_ptrProcess->OnReceive(nErrorCode,this);
	CSocket::OnReceive(nErrorCode);
}

void COConnected::SetProcess(COProcess *ptrProcess)
{
  
	
	
	
	m_ptrProcess=ptrProcess;


}




void COConnected::OnClose(int nErrorCode) 
{
	m_ptrProcess->OnClose(nErrorCode,this);
	
	CSocket::OnClose(nErrorCode);
}
