// OProcess.cpp: implementation of the COProcess class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OProcess.h"
#include "OVoiceChattCtl.h"
#include "OServer.h"
#include "OConnected.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
COVoiceChattCtrl *ptrProcessMain;
COServer *ptrServer;

COProcess::COProcess()
{
 PORT=56740;
   m_MyNick="";
}

COProcess::COProcess(CString nick)
{
   PORT=56740;
   m_MyNick=nick;
   

}

COProcess::~COProcess()
{

	
   
   
}


 
void COProcess::SetParent(LPVOID param)
{
ptrProcessMain=(COVoiceChattCtrl *)param;
}



void COProcess::OnAcceptServer(int err, LPVOID param)
{
ptrServer=(COServer*)param;
COConnected *Socket=new COConnected;
UINT port;
CString ip;

if(ptrServer->Accept(*Socket))
{

Socket->SetProcess(this);
Socket->GetPeerName(ip,port);
Socket->ip=ip;
}
else
delete Socket;

}

void COProcess::SendVoiceInvit(CString nick, CString ip)
{
	
COConnected *Socket=new COConnected;
DWORD arg=0;
CString req="#req#"+nick; 
Socket->IOCtl(FIONBIO,&arg); 
Socket->Create(0);
 
if(Socket->Connect(ip,PORT))
{
Socket->Send((LPCTSTR)req,req.GetLength());
Socket->Close();
delete Socket;
}

}

void COProcess::OnReceive(int err, LPVOID param)
{
COConnected *Socket=(COConnected *)param;
char *buff;
buff=new char[100];
int rec=Socket->Receive(buff,100);
buff[rec]=0;
CString temp,msg,str;
str=buff;	
temp=str.Left(5);
msg=str.Right(str.GetLength()-5);
if(temp=="#req#")
{
 ptrProcessMain->InvokeGetVoiceInv(Socket->ip,msg);
}

else if(temp=="#acc#")
{

 ptrProcessMain->InvokeRequestStatus(true);
 Sound=new COSoundInput;
 Sound->isReq=TRUE;
 Sound->StartSendingVoice(Socket->ip);

}
else if(temp=="#rej#")
{
ptrProcessMain->InvokeRequestStatus(false);
}

}

void COProcess::VoiceInvStatus(bool status, LPCTSTR recip)
{

COConnected *Socket=new COConnected;
DWORD arg=0;
Socket->IOCtl(FIONBIO,&arg); 
Socket->Create(0);
CString req;
if(status)
req="#acc#";
else 
req="#rej#";
if(Socket->Connect(recip,PORT))
{
Socket->Send((LPCTSTR)req,req.GetLength());
Socket->Close();
delete Socket;
}
if(status)
{

Sound=new COSoundInput;
Sound->isReq=FALSE;
Sound->StartSendingVoice(recip);

}






}

void COProcess::OnClose(int err, LPVOID param)
{

	delete ((COConnected *)param);
}

void COProcess::EndVoice()
{

Sound->EndVoice();

}



void COProcess::OnVoiceSocketClose(int err, LPVOID param)
{

if(err==18)
ptrProcessMain->InvokeGetVoiceEnd();
 


}

