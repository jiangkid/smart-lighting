// OVoiceChattCtl.cpp : Implementation of the COVoiceChattCtrl ActiveX Control class.

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OVoiceChattCtl.h"
#include "OVoiceChattPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(COVoiceChattCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(COVoiceChattCtrl, COleControl)
	//{{AFX_MSG_MAP(COVoiceChattCtrl)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(COVoiceChattCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(COVoiceChattCtrl)
	DISP_FUNCTION(COVoiceChattCtrl, "OVoiceInit", OVoiceInit, VT_EMPTY, VTS_NONE)
	
	//}}AFX_DISPATCH_MAP
   DISP_FUNCTION(COVoiceChattCtrl, "OSendVoiceInvitation", OSendVoiceInvitation, VT_EMPTY, VTS_BSTR VTS_BSTR)
   DISP_FUNCTION(COVoiceChattCtrl, "OVoiceInvStatus", OVoiceInvStatus, VT_EMPTY, VTS_BOOL VTS_BSTR)
   DISP_FUNCTION(COVoiceChattCtrl, "OVoiceEnd", OVoiceEnd, VT_EMPTY, VTS_NONE)
   END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(COVoiceChattCtrl, COleControl)
	//{{AFX_EVENT_MAP(COVoiceChattCtrl)

	 EVENT_CUSTOM("GetReqStatus", FireGetReqStatus, VTS_BOOL)
	 EVENT_CUSTOM("GetVoiceInvitation", FireGetVoiceinvitation, VTS_BSTR VTS_BSTR)
	 EVENT_CUSTOM("GetVoiceEndNotice", FireGetVoiceEndNotice, VTS_NONE)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(COVoiceChattCtrl, 1)
	PROPPAGEID(COVoiceChattPropPage::guid)
END_PROPPAGEIDS(COVoiceChattCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(COVoiceChattCtrl, "OVOICECHATT.OVoiceChattCtrl.1",
	0xc2a6c93b, 0x459b, 0x49eb, 0xae, 0x31, 0xca, 0x23, 0x75, 0x78, 0x1a, 0x7c)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(COVoiceChattCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DOVoiceChatt =
		{ 0x7d228ca5, 0x149d, 0x4f73, { 0x81, 0x39, 0x39, 0x1c, 0x32, 0x7f, 0x3e, 0xae } };
const IID BASED_CODE IID_DOVoiceChattEvents =
		{ 0x576abebc, 0xe817, 0x4d83, { 0xab, 0x9a, 0x6f, 0x9c, 0xcd, 0x59, 0xb9, 0xfb } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwOVoiceChattOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(COVoiceChattCtrl, IDS_OVOICECHATT, _dwOVoiceChattOleMisc)


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattCtrl::COVoiceChattCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for COVoiceChattCtrl

BOOL COVoiceChattCtrl::COVoiceChattCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_OVOICECHATT,
			IDB_OVOICECHATT,
			afxRegApartmentThreading,
			_dwOVoiceChattOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattCtrl::COVoiceChattCtrl - Constructor

COVoiceChattCtrl::COVoiceChattCtrl()
{
	InitializeIIDs(&IID_DOVoiceChatt, &IID_DOVoiceChattEvents);
    PORT=56740;

	// TODO: Initialize your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattCtrl::~COVoiceChattCtrl - Destructor

COVoiceChattCtrl::~COVoiceChattCtrl()
{
	
}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattCtrl::OnDraw - Drawing function

void COVoiceChattCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->Ellipse(rcBounds);
}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattCtrl::DoPropExchange - Persistence support

void COVoiceChattCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	

}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattCtrl::OnResetState - Reset control to default state

void COVoiceChattCtrl::OnResetState()
{
	COleControl::OnResetState(); 

	
}


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattCtrl message handlers




void COVoiceChattCtrl::OVoiceInit() 
{

m_ptrProcess=new COProcess;
m_ptrProcess->SetParent(this);
m_ptrServer=new COServer;
m_ptrServer->SetProcess(m_ptrProcess);
m_ptrServer->Create(PORT);
m_ptrServer->Listen(5);
m_ptrVoiceServer=new COVoiceServer;
m_ptrVoiceServer->Create(PORT+100);
m_ptrVoiceServer->Listen();
}


void COVoiceChattCtrl::OSendVoiceInvitation(LPCTSTR yourNick,LPCTSTR recpIp)
{
m_ptrProcess->SendVoiceInvit(yourNick,recpIp);
}

void COVoiceChattCtrl::InvokeGetVoiceInv(CString ip, CString nick)
{

	
FireGetVoiceInvitation(ip,nick);


}

void COVoiceChattCtrl::OVoiceInvStatus(bool status,LPCTSTR recpIp)
{
m_ptrProcess->VoiceInvStatus(status,recpIp);


}

void COVoiceChattCtrl::InvokeRequestStatus(boolean status)
{
FireGetReqStatus(status);
}


void COVoiceChattCtrl::OVoiceEnd() 
{

 m_ptrProcess->EndVoice();

}

void COVoiceChattCtrl::InvokeGetVoiceEnd()
{
 FireGetVoiceEndNotice();
 m_ptrProcess->EndVoice();

}
