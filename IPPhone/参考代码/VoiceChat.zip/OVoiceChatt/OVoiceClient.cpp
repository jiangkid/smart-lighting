// OVoiceClient.cpp : implementation file
//

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OVoiceClient.h"
#include "OProcess.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COVoiceClient
COProcess *VoiceSockProcess;
COSoundOutput *SoundOut;
COVoiceClient::COVoiceClient()
{
IsOutputOpen=FALSE;
buff=new SHORT[6000];
m_isRec=TRUE;

}

COVoiceClient::~COVoiceClient()
{

}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(COVoiceClient, CSocket)
	//{{AFX_MSG_MAP(COVoiceClient)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// COVoiceClient member functions

void COVoiceClient::OnReceive(int nErrorCode) 
{
	
if(!IsOutputOpen)
	{
     SoundOut=new COSoundOutput;      
	 SoundOut->OpenOutput();
	 IsOutputOpen=TRUE;
	}

    Receive(buff,6000);
	SoundOut->OutputBuffer=buff;
    
	CSocket::OnReceive(nErrorCode);
}



void COVoiceClient::OnClose(int nErrorCode) 
{
    if(m_isRec==TRUE)
	{
		VoiceSockProcess->OnVoiceSocketClose(18,this);
	    
	}
	CSocket::OnClose(nErrorCode);
}

void COVoiceClient::SetProcess(LPVOID param)
{
VoiceSockProcess=(COProcess *)param;
}


void COVoiceClient::EndVoice()
{
  SoundOut->CloseOutput();
}
