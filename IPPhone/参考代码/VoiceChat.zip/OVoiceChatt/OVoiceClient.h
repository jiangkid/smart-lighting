#if !defined(AFX_OVOICECLIENT_H__EDF336F1_AD88_44FD_8A39_D3927DD3AC41__INCLUDED_)
#define AFX_OVOICECLIENT_H__EDF336F1_AD88_44FD_8A39_D3927DD3AC41__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OVoiceClient.h : header file
//

#include "OSoundOutput.h"


/////////////////////////////////////////////////////////////////////////////
// COVoiceClient command target

class COVoiceClient : public CSocket
{
// Attributes
public:
//COSoundOutput *Sound;
SHORT *buff;
// Operations
public:
	COVoiceClient();
	virtual ~COVoiceClient();

// Overrides
public:
	void EndVoice();
	BOOL m_isRec;
	void SetProcess(LPVOID param);
	BOOL IsOutputOpen;
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COVoiceClient)
	public:
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(COVoiceClient)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OVOICECLIENT_H__EDF336F1_AD88_44FD_8A39_D3927DD3AC41__INCLUDED_)
