#if !defined(AFX_OVOICECHATTCTL_H__859FEB76_D977_4B69_91FE_C248F75089D0__INCLUDED_)
#define AFX_OVOICECHATTCTL_H__859FEB76_D977_4B69_91FE_C248F75089D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "OProcess.h"
#include "OServer.h"
#include "OVoiceServer.h"

// OVoiceChattCtl.h : Declaration of the COVoiceChattCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// COVoiceChattCtrl : See OVoiceChattCtl.cpp for implementation.

class COVoiceChattCtrl : public COleControl
{
	DECLARE_DYNCREATE(COVoiceChattCtrl)

// Constructor
public:
	COServer *m_ptrServer;
	COProcess *m_ptrProcess;
	COVoiceServer *m_ptrVoiceServer;
	COVoiceChattCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COVoiceChattCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~COVoiceChattCtrl();

	DECLARE_OLECREATE_EX(COVoiceChattCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(COVoiceChattCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(COVoiceChattCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(COVoiceChattCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(COVoiceChattCtrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
public:
	DECLARE_MESSAGE_MAP()
	afx_msg void OSendVoiceInvitation(LPCTSTR yourNick,LPCTSTR recpIp);
    afx_msg void OVoiceInvStatus(bool status,LPCTSTR recpIp);
    afx_msg void OVoiceEnd();
// Dispatch maps
	//{{AFX_DISPATCH(COVoiceChattCtrl)
	afx_msg void OVoiceInit();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	
// Event maps
	//{{AFX_EVENT(COVoiceChattCtrl)
	void FireGetVoiceInvitation(LPCTSTR ip, LPCTSTR nick)
		{FireEvent(eventidGetVoiceInvitation,EVENT_PARAM(VTS_BSTR  VTS_BSTR), ip, nick);}
	void FireGetReqStatus(BOOL status)
		{FireEvent(eventidGetReqStatus,EVENT_PARAM(VTS_BOOL), status);}
	void FireGetVoiceEndNotice()
		{FireEvent(eventidGetVoiceEndNotice,EVENT_PARAM(VTS_NONE));}
	//}}AFX_EVENT


	
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:


	void InvokeGetVoiceEnd();
	void InvokeRequestStatus(boolean status);
	void InvokeGetVoiceInv(CString ip,CString nick);
	UINT PORT;
	enum {
    	//{{AFX_DISP_ID(COVoiceChattCtrl)
	dispidOVoiceInit = 1L,
	eventidGetVoiceInvitation =1L,
	eventidGetReqStatus = 2L,
	eventidGetVoiceEndNotice =3L,
	//}}AFX_DISP_ID
	dispidOSendVoiceInvitation=2L,
	dispidOVoiceInvStatus=3L,
	dispidOVoiceEnd=4L,
	
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OVOICECHATTCTL_H__859FEB76_D977_4B69_91FE_C248F75089D0__INCLUDED)
