#if !defined(AFX_OSERVER_H__D1B8351F_E154_4AF0_8B94_9821F569FA9C__INCLUDED_)
#define AFX_OSERVER_H__D1B8351F_E154_4AF0_8B94_9821F569FA9C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OServer.h : header file
//
#include "OProcess.h"


/////////////////////////////////////////////////////////////////////////////
// COServer command target

class COServer : public CSocket
{
// Attributes
public:

// Operations
public:
	COServer();
	virtual ~COServer();

// Overrides
public:
	COProcess * m_ptrProcess;
	void SetProcess(COProcess *ptrProcess);
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COServer)
	public:
	virtual void OnAccept(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(COServer)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OSERVER_H__D1B8351F_E154_4AF0_8B94_9821F569FA9C__INCLUDED_)
