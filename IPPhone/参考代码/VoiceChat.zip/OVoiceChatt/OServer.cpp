// OServer.cpp : implementation file
//

#include "stdafx.h"
#include "OVoiceChatt.h"
#include "OServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COServer

COServer::COServer()
{
}

COServer::~COServer()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(COServer, CSocket)
	//{{AFX_MSG_MAP(COServer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// COServer member functions

void COServer::OnAccept(int nErrorCode) 
{
	m_ptrProcess->OnAcceptServer(nErrorCode,this);
	CSocket::OnAccept(nErrorCode);
}

void COServer::SetProcess(COProcess *ptrProcess)
{
m_ptrProcess=ptrProcess;

}
