// OSoundOutput.h: interface for the COSoundOutput class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OSOUNDOUTPUT_H__CF058665_FE4D_4CB0_944D_3BADC303D709__INCLUDED_)
#define AFX_OSOUNDOUTPUT_H__CF058665_FE4D_4CB0_944D_3BADC303D709__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <mmsystem.h>

#define MAX_OUTPUT_SAMPLES 2048  
#define MAX_VOIE 2
#define MAX_SIZE_SAMPLES  1  
#define MAX_SIZE_OUTPUT_BUFFER   MAX_OUTPUT_SAMPLES*MAX_VOIE*MAX_SIZE_SAMPLES 
//#define MAX_SAMPLES 8192  
//#define MAX_VOIE 2
//#define MAX_SIZE_SAMPLES  1 
//#define MAX_SIZE_INPUT_BUFFER   MAX_SAMPLES*MAX_VOIE*MAX_SIZE_SAMPLES 
//#define DEFAULT_CAL_OFFSET -395
//#define DEFAULT_CAL_GAIN   1.0



class COSoundOutput  
{
public:
	SHORT  *OutputBuffer,m_Toggle;
	WAVEOUTCAPS		m_WaveOutDevCaps;
    HWAVEOUT		m_WaveOut;
	WAVEHDR			m_WaveHeader[2];
    WAVEFORMATEX	m_WaveFormat;
	HANDLE m_WaveOutEvent;
	CWinThread * m_WaveOutThread;
	BOOL m_Terminate;
	UINT m_WaveOutSampleRate,m_SizeRecord;
	int  m_NbMaxSamples;
	 


public:
	COSoundOutput();
	virtual ~COSoundOutput();
	void StopOutput();
	void CloseOutput();
	void AddBuffer();
	void OpenOutput();
	void WaveInitFormat(WORD nCh,DWORD nSampleRate,WORD BitsPerSample);
	

};
UINT WaveOutThreadProc( LPVOID pParam);
#endif // !defined(AFX_OSOUNDOUTPUT_H__CF058665_FE4D_4CB0_944D_3BADC303D709__INCLUDED_)
