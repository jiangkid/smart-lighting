#if !defined(AFX_OVOICECHATTPPG_H__6060A5A1_C9BA_488D_977F_1D992BB2227F__INCLUDED_)
#define AFX_OVOICECHATTPPG_H__6060A5A1_C9BA_488D_977F_1D992BB2227F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// OVoiceChattPpg.h : Declaration of the COVoiceChattPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// COVoiceChattPropPage : See OVoiceChattPpg.cpp.cpp for implementation.

class COVoiceChattPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(COVoiceChattPropPage)
	DECLARE_OLECREATE_EX(COVoiceChattPropPage)

// Constructor
public:
	COVoiceChattPropPage();

// Dialog Data
	//{{AFX_DATA(COVoiceChattPropPage)
	enum { IDD = IDD_PROPPAGE_OVOICECHATT };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(COVoiceChattPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OVOICECHATTPPG_H__6060A5A1_C9BA_488D_977F_1D992BB2227F__INCLUDED)
