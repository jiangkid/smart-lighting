// OVoiceChattClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "OVoiceChattClient.h"
#include "OVoiceChattClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// COVoiceChattClientDlg dialog

COVoiceChattClientDlg::COVoiceChattClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COVoiceChattClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COVoiceChattClientDlg)
	m_strIp = _T("");
	m_strNick = _T("");
	m_strStatus = _T("Not Connected");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	
	
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void COVoiceChattClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COVoiceChattClientDlg)
	DDX_Text(pDX, IDC_EDIT_IP, m_strIp);
	DDX_Control(pDX, IDC_OVOICECHATTCTRL1, m_ctlVoice);
	DDX_Text(pDX, IDC_EDIT_NICK, m_strNick);
	DDX_Text(pDX, IDC_EDIT1, m_strStatus);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(COVoiceChattClientDlg, CDialog)
	//{{AFX_MSG_MAP(COVoiceChattClientDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SEIN, OnButtonSein)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON_END, OnButtonEnd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COVoiceChattClientDlg message handlers

BOOL COVoiceChattClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void COVoiceChattClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR COVoiceChattClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void COVoiceChattClientDlg::OnButtonSein() 
{
UpdateData(TRUE);
m_ctlVoice.OSendVoiceInvitation(m_strNick,m_strIp);

}

BEGIN_EVENTSINK_MAP(COVoiceChattClientDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(COVoiceChattClientDlg)
	ON_EVENT(COVoiceChattClientDlg, IDC_OVOICECHATTCTRL1, 1 /* GetVoiceInvitation */, OnGetVoiceInvitation, VTS_BSTR VTS_BSTR)
	ON_EVENT(COVoiceChattClientDlg, IDC_OVOICECHATTCTRL1, 2 /* GetReqStatus */, OnGetReqStatus, VTS_I4)
	ON_EVENT(COVoiceChattClientDlg, IDC_OVOICECHATTCTRL1, 3 /* GetVoiceEndNotice */, OnGetVoiceEndNoticeOvoicechattctrl1, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void COVoiceChattClientDlg::OnGetVoiceInvitation(LPCTSTR ip, LPCTSTR nick) 
{

	m_ip=ip;
	CString str=nick;
	str+=" wants to have voice chat with you";
	if(AfxMessageBox(str,MB_YESNO)==IDYES)
	{
	m_ctlVoice.OVoiceInvStatus(1,ip);
	
	}
	else
    m_ctlVoice.OVoiceInvStatus(0,ip);

}

void COVoiceChattClientDlg::OnGetReqStatus(long status) 
{
	
if(status==0)
AfxMessageBox("request rejected");
else
{
m_strStatus="Connecting";
UpdateData(FALSE);
}
}

void COVoiceChattClientDlg::OnButton1() 
{
m_ctlVoice.OVoiceInit();	
}



void COVoiceChattClientDlg::OnButtonEnd() 
{
 m_ctlVoice.OVoiceEnd();	

}

void COVoiceChattClientDlg::OnGetVoiceEndNoticeOvoicechattctrl1() 
{
AfxMessageBox("Voice Conversation Has Been Ended");		
}
