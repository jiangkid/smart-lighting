// OVoiceChattClientDlg.h : header file
//
//{{AFX_INCLUDES()
#include "ovoicechatt.h"
//}}AFX_INCLUDES

#if !defined(AFX_OVOICECHATTCLIENTDLG_H__B97D846F_2C89_40DB_9F5C_F8EF50F3022C__INCLUDED_)
#define AFX_OVOICECHATTCLIENTDLG_H__B97D846F_2C89_40DB_9F5C_F8EF50F3022C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// COVoiceChattClientDlg dialog

class COVoiceChattClientDlg : public CDialog
{
// Construction
public:
	CString m_ip;
	COVoiceChattClientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(COVoiceChattClientDlg)
	enum { IDD = IDD_OVOICECHATTCLIENT_DIALOG };
	CString	m_strIp;
	COVoiceChatt	m_ctlVoice;
	CString	m_strNick;
	CString	m_strStatus;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COVoiceChattClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(COVoiceChattClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonSein();
	afx_msg void OnGetVoiceInvitation(LPCTSTR ip, LPCTSTR nick);
	afx_msg void OnGetReqStatus(long status);
	afx_msg void OnButton1();
	afx_msg void OnButtonEnd();
	afx_msg void OnGetVoiceEndNoticeOvoicechattctrl1();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OVOICECHATTCLIENTDLG_H__B97D846F_2C89_40DB_9F5C_F8EF50F3022C__INCLUDED_)
