// OVoiceChattClient.h : main header file for the OVOICECHATTCLIENT application
//

#if !defined(AFX_OVOICECHATTCLIENT_H__B330161B_7E9E_40E0_BA00_AF4A17E84542__INCLUDED_)
#define AFX_OVOICECHATTCLIENT_H__B330161B_7E9E_40E0_BA00_AF4A17E84542__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// COVoiceChattClientApp:
// See OVoiceChattClient.cpp for the implementation of this class
//

class COVoiceChattClientApp : public CWinApp
{
public:
	COVoiceChattClientApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COVoiceChattClientApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(COVoiceChattClientApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OVOICECHATTCLIENT_H__B330161B_7E9E_40E0_BA00_AF4A17E84542__INCLUDED_)
